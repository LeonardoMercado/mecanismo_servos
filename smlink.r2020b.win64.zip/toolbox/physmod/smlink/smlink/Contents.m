% Simscape Multibody Link
% Version 7.2 (R2020b) 29-Jul-2020

%   Copyright 2007-2020 The MathWorks, Inc.
